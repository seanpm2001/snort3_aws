--
-- Array of directories where relevant rules are found
-- Used by load_ips.lua to create ips.rules and ips.states
--

ruleDirs = {
   "../../rules/3.0.0.0",
   "../../builtins/3.0.0.0-0",
   "../../modules/stubs"
}

