--io.stderr:write("default_binder.lua loaded\n")
default_binder =
{
    -- port bindings required for protocols without wizard support
    { when = { proto = 'udp', ports = '53', role = 'server' },  use = { type = 'dns' } },
    { when = { proto = 'tcp', ports = '53', role = 'server' },  use = { type = 'dns' } },
    { when = { proto = 'tcp', ports = '111', role = 'server' }, use = { type = 'rpc_decode' } },
    { when = { proto = 'tcp', ports = '502', role = 'server' }, use = { type = 'modbus' } },
    { when = { proto = 'tcp', ports = '102', role = 'server' }, use = { type = 's7commplus' } },
    { when = { proto = 'tcp', ports = '2123 2152 3386', role = 'server' }, use = { type = 'gtp_inspect' } },
    { when = { proto = 'udp', ports = '22222', role = 'server' }, use = { type = 'cip' } },
    { when = { proto = 'tcp', ports = '44818', role = 'server' }, use = { type = 'cip' } },
    { when = { proto = 'tcp', ports = '2404', role='server' }, use = { type = 'iec104' } },

    { when = { proto = 'tcp', service = 'dcerpc' }, use = { type = 'dce_tcp' } },
    { when = { proto = 'udp', service = 'dcerpc' }, use = { type = 'dce_udp' } },

    { when = { service = 'netbios-ssn' },      use = { type = 'dce_smb' } },
    { when = { service = 'dce_http_server' },  use = { type = 'dce_http_server' } },
    { when = { service = 'dce_http_proxy' },   use = { type = 'dce_http_proxy' } },

    { when = { service = 'dnp3' },             use = { type = 'dnp3' } },
    { when = { service = 'dns' },              use = { type = 'dns' } },
    { when = { service = 'ftp' },              use = { type = 'ftp_server' } },
    { when = { service = 'ftp-data' },         use = { type = 'ftp_data' } },
    { when = { service = 'gtp' },              use = { type = 'gtp_inspect' } },
    { when = { service = 'imap' },             use = { type = 'imap' } },
    { when = { service = 'http' },             use = { type = 'http_inspect' } },
    { when = { service = 'http2' },            use = { type = 'http2_inspect' } },
    { when = { service = 'modbus' },           use = { type = 'modbus' } },
    { when = { service = 's7commplus' },       use = { type = 's7commplus' } },
    { when = { service = 'pop3' },             use = { type = 'pop' } },
    { when = { service = 'ssh' },              use = { type = 'ssh' } },
    { when = { service = 'sip' },              use = { type = 'sip' } },
    { when = { service = 'smtp' },             use = { type = 'smtp' } },
    { when = { service = 'ssl' },              use = { type = 'ssl' } },
    { when = { service = 'sunrpc' },           use = { type = 'rpc_decode' } },
    { when = { service = 'telnet' },           use = { type = 'telnet' } },

    { use = { type = 'wizard' } }
}

