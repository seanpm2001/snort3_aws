--io.stderr:write("baseconfig.lua loaded\n")
include('snort_defaults.lua')
include('talos_functions.lua')
include('file_magic.lua')

env = getfenv()

detection = { }
search_engine = { }
normalizer = { }

stream = { }
stream_ip = { }
stream_icmp = { }
stream_tcp = { }
stream_udp = { }
stream_user = { }
stream_file = { }

appid = { }

arp_spoof = { }

dns = { }

http_inspect = { }
if MISSING_HTTP2 == nil then
   http2_inspect = { }
end

imap = { }
pop = { }

rpc_decode = { }
ssh = { }
ssl = { }

telnet = { }

dce_smb = { }
dce_tcp = { }
dce_udp = { }
dce_http_proxy = { }
dce_http_server = { }

---- Industrial Control Systems (ICS) protocols
--sip = { }
--dnp3 = { }
--modbus = { }
--s7commplus = { }
--cip = { }
--
--if MISSING_IEC104 == nil then
--   iec104 = { }
--end
--
--gtp_inspect = default_gtp

port_scan = default_med_port_scan

smtp = default_smtp

ftp_server = default_ftp_server
ftp_client = { }
ftp_data = { }

-- see file_magic.lua for file id rules
file_id = { file_rules = file_magic }

---------------------------------------------------------------------------
-- 4. configure performance
---------------------------------------------------------------------------

-- use latency to monitor / enforce packet and rule thresholds
latency = { }

-- use these to capture perf data for analysis and tuning
--profiler = { }
perf_monitor = { }


---------------------------------------------------------------------------
-- 3. configure bindings
---------------------------------------------------------------------------

wizard = default_wizard
TALOS.functions.add_binder_entries()

---------------------------------------------------------------------------
-- 5. configure detection
---------------------------------------------------------------------------
-- this is also in load_ips.lua, where it belongs.  Remove this at some point.
references = default_references
classifications = default_classifications

