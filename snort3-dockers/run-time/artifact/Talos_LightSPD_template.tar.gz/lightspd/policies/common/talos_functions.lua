--io.stderr:write("talos_functions.lua loaded\n")
include('default_binder.lua')

if TALOS == nil then
   TALOS = {}
end

if TALOS.functions == nil then
   TALOS.functions = {}
end

TALOS.functions.push_array = function(existing, new)

   existing = existing or {}

   if new then
      for k,v in pairs(new) do
         table.insert(existing, v)
      end
   end

   return existing
end


TALOS.functions.binder_entry_exists = function(name)

   for i, v in pairs (binder) do
      if v.use ~= nil then
         if v.use.type == name then
            --print("Found binder entry for " .. name)
            return true
         end
      end
   end

   return false
end

TALOS.functions.add_binder_entries = function()

   -- if no binder currently exists, create it now
   if binder == nil then
      binder = {}
   end

   -- we split them out to maintain heirarchy -- policies, ports, services, everything else
   -- for existing binders, we maintain order (within those groups), and add our
   -- new stuff to the end of the respective category
   policy_bindings = {}
   port_bindings = {}
   service_bindings = {}
   other_bindings = {}  -- everything else

   -- Copy existing bindings that are in use to the new binder
   for i, v in pairs (binder) do

      if v.use == nil or v.use.type == nil then -- oddballs
         table.insert(other_bindings, v)
      elseif v.use.inspection_policy ~= nil or v.use.ips_policy ~= nil then -- policies
         table.insert(policy_bindings, v)
      elseif env[v.use.type] ~= nil then -- inspector is loaded, so keep existing binding
         if v.when == nil then
            table.insert(other_bindings, v)
         else
            if v.when.ports ~= nil then
               table.insert(port_bindings, v)
            elseif v.when.service ~= nil then
               table.insert(service_bindings, v)
            else
               table.insert(other_bindings, v) -- catch-all, just in case
            end
         end
      end
   end

   -- Copy default bindings for modules in use but without a binder
   for i, v in pairs (default_binder) do
       if v.use ~= nil then
          if env[v.use.type] ~= nil then

             if not TALOS.functions.binder_entry_exists(v.use.type) then
                -- print("Adding default binder for " .. v.use.type)
               if v.when == nil then
                  table.insert(other_bindings, v)
               else
                  if v.when.ports ~= nil then
                     table.insert(port_bindings, v)
                  elseif v.when.service ~= nil then
                     table.insert(service_bindings, v)
                  else
                     table.insert(other_bindings, v) -- catch-all, just in case
                  end
               end
             end
          end
       end
   end

   -- empty the current binder to rebuild it
   binder = {}
   for i, v in pairs (policy_bindings) do
      table.insert(binder, v)
   end
   for i, v in pairs (port_bindings) do
      table.insert(binder, v)
   end
   for i, v in pairs (service_bindings) do
      table.insert(binder, v)
   end
   for i, v in pairs (other_bindings) do
      table.insert(binder, v)
   end
end


TALOS.functions.enable_inspector = function(inspector_name, seclevel)

   env = getfenv()

   -- default seclevel to sane default (same as in NAP config)
   if seclevel == nil then
      if securityLevel ~= nil then
         seclevel = securityLevel
      else
         seclevel = 20 -- fall back to balanced security and connectivity if necessary
      end
   end

   -- Don't reconfigure with defaults if it's already configured
   if env[inspector_name] == nil then
      -- ultimately, this will set a configuration based upon the security level
      env[inspector_name] = {}

      if inspector_name == "cip" then
         cip.embedded_cip_path = '0x2 0x36'
      end

      if inspector_name == "gtp_inspect" then
         gtp_inspect = default_gtp
      end
   end

   TALOS.functions.add_binder_entries()

   return true
end

